import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="navbar">
      <div className="brand">HR Helpdesk & Incident Management</div>
      <div className="nav-links">
        {user.role === "hr_agent" && <Link to="/dashboard">Dashboard</Link>}
        <Link to="/tickets">Tickets</Link>
        <Link to="/tickets/new">New Ticket</Link>
        <Link to="/kb">Knowledge Base</Link>
        <span style={{ marginRight: "1rem", fontSize: "0.85rem", color: "#9fb1bc" }}>
          {user.name} ({user.role === "hr_agent" ? "HR Agent" : "Employee"})
        </span>
        <button className="linklike" onClick={handleLogout}>Log out</button>
      </div>
    </div>
  );
}
