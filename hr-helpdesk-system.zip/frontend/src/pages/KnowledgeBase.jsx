import { useEffect, useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";

export default function KnowledgeBase() {
  const { user } = useAuth();
  const [articles, setArticles] = useState([]);
  const [q, setQ] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", category: "General HR Query", body: "" });
  const [error, setError] = useState("");

  const load = () => {
    api.get("/kb", { params: q ? { q } : {} }).then((res) => setArticles(res.data.articles));
  };

  useEffect(load, [q]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/kb", form);
      setForm({ title: "", category: "General HR Query", body: "" });
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.response?.data?.error || "Could not create article");
    }
  };

  return (
    <div className="container">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>Knowledge Base</h2>
        {user.role === "hr_agent" && (
          <button className="btn" onClick={() => setShowForm(!showForm)}>
            {showForm ? "Cancel" : "+ New Article"}
          </button>
        )}
      </div>

      <input
        placeholder="Search articles..."
        value={q}
        onChange={(e) => setQ(e.target.value)}
        style={{ marginBottom: "1rem", maxWidth: "400px" }}
      />

      {showForm && (
        <form onSubmit={handleCreate} className="card">
          <div>
            <label>Title</label>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          </div>
          <div>
            <label>Category</label>
            <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          </div>
          <div>
            <label>Body</label>
            <textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} required />
          </div>
          {error && <div className="error-msg">{error}</div>}
          <button className="btn" type="submit">Publish Article</button>
        </form>
      )}

      {articles.map((a) => (
        <div className="card" key={a.id}>
          <h3>{a.title}</h3>
          <p className="ticket-meta">{a.category}</p>
          <p style={{ whiteSpace: "pre-line" }}>{a.body}</p>
        </div>
      ))}
      {articles.length === 0 && <p>No articles found.</p>}
    </div>
  );
}
