import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import { useAuth } from "../AuthContext";

export default function Tickets() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [status, setStatus] = useState("");
  const [category, setCategory] = useState("");

  const load = () => {
    const params = {};
    if (status) params.status = status;
    if (category) params.category = category;
    api.get("/tickets", { params }).then((res) => {
      setTickets(res.data.tickets);
      setCategories(res.data.categories);
    });
  };

  useEffect(load, [status, category]);

  return (
    <div className="container">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>{user.role === "hr_agent" ? "All Tickets" : "My Tickets"}</h2>
        <Link className="btn" to="/tickets/new" style={{ textDecoration: "none" }}>+ New Ticket</Link>
      </div>

      <div className="filters">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All Statuses</option>
          <option>Open</option>
          <option>In Progress</option>
          <option>Resolved</option>
          <option>Closed</option>
        </select>
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="card">
        {tickets.length === 0 && <p>No tickets found.</p>}
        {tickets.map((t) => (
          <div className="ticket-row" key={t.id}>
            <div>
              <Link to={`/tickets/${t.id}`}><strong>#{t.id} {t.subject}</strong></Link>
              <div className="ticket-meta">{t.category} · Priority: {t.priority}</div>
            </div>
            <span className={`badge ${t.status.replace(" ", "-")}`}>{t.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
