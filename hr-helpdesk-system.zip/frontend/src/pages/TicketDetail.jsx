import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../api";
import { useAuth } from "../AuthContext";

export default function TicketDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [ticket, setTicket] = useState(null);
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");

  const load = () => {
    api.get(`/tickets/${id}`).then((res) => setTicket(res.data.ticket)).catch((err) =>
      setError(err.response?.data?.error || "Could not load ticket")
    );
  };

  useEffect(load, [id]);

  const updateStatus = async (status) => {
    await api.patch(`/tickets/${id}`, { status });
    load();
  };

  const addComment = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    await api.post(`/tickets/${id}/comments`, { text: comment });
    setComment("");
    load();
  };

  if (error) return <div className="container error-msg">{error}</div>;
  if (!ticket) return <div className="container">Loading...</div>;

  return (
    <div className="container">
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <h2>#{ticket.id} {ticket.subject}</h2>
          <span className={`badge ${ticket.status.replace(" ", "-")}`}>{ticket.status}</span>
        </div>
        <p className="ticket-meta">
          Category: {ticket.category} · Priority: {ticket.priority} · Created:{" "}
          {new Date(ticket.createdAt).toLocaleString()}
        </p>
        <p>{ticket.description}</p>

        {user.role === "hr_agent" && (
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "1rem" }}>
            {["Open", "In Progress", "Resolved", "Closed"].map((s) => (
              <button
                key={s}
                className={`btn ${s === ticket.status ? "" : "secondary"}`}
                onClick={() => updateStatus(s)}
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="card">
        <h3>Comments</h3>
        {ticket.comments.length === 0 && <p>No comments yet.</p>}
        {ticket.comments.map((c, i) => (
          <div className="comment" key={i}>
            <div className="author">{c.author}</div>
            <div className="time">{new Date(c.createdAt).toLocaleString()}</div>
            <div>{c.text}</div>
          </div>
        ))}
        <form onSubmit={addComment} style={{ marginTop: "1rem" }}>
          <textarea
            placeholder="Add a comment or update..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <button className="btn" type="submit">Post Comment</button>
        </form>
      </div>
    </div>
  );
}
