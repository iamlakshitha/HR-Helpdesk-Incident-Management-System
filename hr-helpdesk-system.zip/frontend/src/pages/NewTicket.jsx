import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

const CATEGORIES = [
  "SuccessFactors/ESS Login Issue",
  "Payroll Query",
  "System Error",
  "Access Request",
  "General HR Query",
];

export default function NewTicket() {
  const [form, setForm] = useState({
    subject: "",
    category: CATEGORIES[0],
    description: "",
    priority: "Medium",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const { data } = await api.post("/tickets", form);
      navigate(`/tickets/${data.ticket.id}`);
    } catch (err) {
      setError(err.response?.data?.error || "Could not create ticket");
    }
  };

  return (
    <div className="container">
      <h2>Raise a New Ticket</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Subject</label>
          <input name="subject" value={form.subject} onChange={handleChange} required />
        </div>
        <div>
          <label>Category</label>
          <select name="category" value={form.category} onChange={handleChange}>
            {CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </div>
        <div>
          <label>Priority</label>
          <select name="priority" value={form.priority} onChange={handleChange}>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>
        </div>
        <div>
          <label>Description</label>
          <textarea name="description" value={form.description} onChange={handleChange} required />
        </div>
        {error && <div className="error-msg">{error}</div>}
        <button className="btn" type="submit">Submit Ticket</button>
      </form>
    </div>
  );
}
