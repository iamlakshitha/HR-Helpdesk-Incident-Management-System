import { useEffect, useState } from "react";
import api from "../api";

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/dashboard/stats")
      .then((res) => setStats(res.data))
      .catch((err) => setError(err.response?.data?.error || "Failed to load stats"));
  }, []);

  if (error) return <div className="container error-msg">{error}</div>;
  if (!stats) return <div className="container">Loading...</div>;

  return (
    <div className="container">
      <h2>HR Support Dashboard</h2>
      <div className="grid grid-3" style={{ marginBottom: "1.5rem" }}>
        <div className="stat-box">
          <div className="num">{stats.totalTickets}</div>
          <div className="label">Total Tickets</div>
        </div>
        <div className="stat-box">
          <div className="num">{stats.avgOpenAgeDays}</div>
          <div className="label">Avg. Age of Open Tickets (days)</div>
        </div>
        <div className="stat-box">
          <div className="num">{stats.kbArticleCount}</div>
          <div className="label">Knowledge Base Articles</div>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <h3>Tickets by Status</h3>
          {Object.entries(stats.byStatus).map(([status, count]) => (
            <div key={status} className="ticket-row">
              <span className={`badge ${status.replace(" ", "-")}`}>{status}</span>
              <span>{count}</span>
            </div>
          ))}
          {Object.keys(stats.byStatus).length === 0 && <p>No tickets yet.</p>}
        </div>
        <div className="card">
          <h3>Tickets by Category</h3>
          {Object.entries(stats.byCategory).map(([cat, count]) => (
            <div key={cat} className="ticket-row">
              <span>{cat}</span>
              <span>{count}</span>
            </div>
          ))}
          {Object.keys(stats.byCategory).length === 0 && <p>No tickets yet.</p>}
        </div>
      </div>
    </div>
  );
}
