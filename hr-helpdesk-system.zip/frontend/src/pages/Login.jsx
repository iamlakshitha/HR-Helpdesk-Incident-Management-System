import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";

export default function Login() {
  const [email, setEmail] = useState("hragent@demo.com");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const user = await login(email, password);
      navigate(user.role === "hr_agent" ? "/dashboard" : "/tickets");
    } catch (err) {
      setError(err.response?.data?.error || "Login failed");
    }
  };

  return (
    <div className="auth-wrap">
      <h2>HR Helpdesk Login</h2>
      <p style={{ fontSize: "0.85rem", color: "#666" }}>
        Demo accounts — HR Agent: hragent@demo.com / password123 &nbsp;|&nbsp;
        Employee: employee@demo.com / password123
      </p>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
        </div>
        <div>
          <label>Password</label>
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
        </div>
        {error && <div className="error-msg">{error}</div>}
        <button className="btn" type="submit">Log in</button>
      </form>
      <p style={{ marginTop: "1rem", fontSize: "0.9rem" }}>
        No account? <Link to="/register">Register as an employee</Link>
      </p>
    </div>
  );
}
