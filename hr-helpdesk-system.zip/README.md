# HR Helpdesk & Incident Management System

A full-stack helpdesk application for managing employee HR/IT support tickets — modeled directly on real HCM support workflows: monitoring incidents, resolving SuccessFactors/ESS login issues, and maintaining a searchable knowledge base.

Built with **Node.js/Express** (backend) and **React + Vite** (frontend).

## Why this project

This project simulates the day-to-day responsibilities of an HRIS/HCM support role:

- Monitoring a helpdesk system and managing incidents/service requests
- Resolving SuccessFactors/ESS login-style issues
- Documenting client requirements and knowledge base articles
- Role-based access: HR Agents vs. Employees

## Features

- **Authentication** — JWT-based login/register, role-based access (`hr_agent` / `employee`)
- **Ticketing** — create, view, filter (by status/category), assign, and update tickets
- **Categories** map directly to real HCM support categories: SuccessFactors/ESS Login Issue, Payroll Query, System Error, Access Request, General HR Query
- **Comments/audit trail** on each ticket
- **Knowledge Base** — searchable articles, agent-authored
- **Dashboard** — ticket counts by status/category, average open-ticket age (SLA-style metric)

## Tech stack

- Backend: Node.js, Express, JWT (`jsonwebtoken`), `bcryptjs` for password hashing
- Data: JSON file storage (`backend/data/db.json`) — zero native dependencies, runs anywhere
- Frontend: React 18, React Router, Axios, Vite

## Project structure

```
hr-helpdesk-system/
├── backend/
│   ├── server.js
│   ├── db.js
│   ├── seed.js
│   ├── middleware/auth.js
│   ├── routes/ (auth.js, tickets.js, kb.js, dashboard.js)
│   └── data/db.json
└── frontend/
    └── src/ (pages, components, AuthContext, api.js)
```

## Getting started

### Backend
```bash
cd backend
npm install
npm run seed     # creates demo data + demo accounts
npm start        # runs on http://localhost:5001
```

### Frontend
```bash
cd frontend
npm install
npm run dev       # runs on http://localhost:5173
```

### Demo accounts
| Role       | Email                | Password    |
|------------|-----------------------|-------------|
| HR Agent   | hragent@demo.com      | password123 |
| Employee   | employee@demo.com     | password123 |

## API overview

| Method | Endpoint                     | Description                          |
|--------|-------------------------------|---------------------------------------|
| POST   | /api/auth/register            | Create an employee account            |
| POST   | /api/auth/login                | Log in, returns JWT                   |
| GET    | /api/tickets                   | List tickets (role-scoped, filterable)|
| POST   | /api/tickets                   | Create a ticket                       |
| GET    | /api/tickets/:id                | Ticket detail                         |
| PATCH  | /api/tickets/:id                | Update status/priority (agent only)   |
| POST   | /api/tickets/:id/comments       | Add a comment                         |
| GET    | /api/kb                         | List/search knowledge base articles   |
| POST   | /api/kb                         | Publish an article (agent only)       |
| GET    | /api/dashboard/stats            | Ticket metrics (agent only)           |

## Possible extensions

- Email notifications on ticket updates
- SLA breach alerts
- File attachments on tickets
- Role: "manager" for approval workflows
