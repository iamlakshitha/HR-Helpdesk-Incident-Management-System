// Simple JSON-file-based data store.
// Chosen deliberately over a real DB so the project runs anywhere with zero
// native build dependencies (no SQLite/Postgres install needed to demo it).
const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "data", "db.json");

function readDB() {
  const raw = fs.readFileSync(DB_PATH, "utf-8");
  return JSON.parse(raw);
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function nextId(items) {
  return items.length ? Math.max(...items.map((i) => i.id)) + 1 : 1;
}

module.exports = { readDB, writeDB, nextId };
