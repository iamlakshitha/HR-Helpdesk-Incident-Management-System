const express = require("express");
const { readDB, writeDB, nextId } = require("../db");
const { auth, requireRole } = require("../middleware/auth");

const router = express.Router();

const CATEGORIES = [
  "SuccessFactors/ESS Login Issue",
  "Payroll Query",
  "System Error",
  "Access Request",
  "General HR Query",
];

// List tickets: agents see everything (optionally filtered), employees see only their own
router.get("/", auth, (req, res) => {
  const db = readDB();
  const { status, category } = req.query;
  let tickets =
    req.user.role === "hr_agent"
      ? db.tickets
      : db.tickets.filter((t) => t.createdBy === req.user.id);

  if (status) tickets = tickets.filter((t) => t.status === status);
  if (category) tickets = tickets.filter((t) => t.category === category);

  tickets = [...tickets].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ tickets, categories: CATEGORIES });
});

router.get("/:id", auth, (req, res) => {
  const db = readDB();
  const ticket = db.tickets.find((t) => t.id === Number(req.params.id));
  if (!ticket) return res.status(404).json({ error: "Ticket not found" });
  if (req.user.role !== "hr_agent" && ticket.createdBy !== req.user.id) {
    return res.status(403).json({ error: "You do not have access to this ticket" });
  }
  res.json({ ticket });
});

router.post("/", auth, (req, res) => {
  const { subject, category, description, priority } = req.body;
  if (!subject || !category || !description) {
    return res.status(400).json({ error: "subject, category and description are required" });
  }
  if (!CATEGORIES.includes(category)) {
    return res.status(400).json({ error: "Invalid category" });
  }
  const db = readDB();
  const ticket = {
    id: nextId(db.tickets),
    subject,
    category,
    description,
    status: "Open",
    priority: priority || "Medium",
    createdBy: req.user.id,
    assignedTo: null,
    comments: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.tickets.push(ticket);
  writeDB(db);
  res.status(201).json({ ticket });
});

// Update status / assignment - HR agents only
router.patch("/:id", auth, requireRole("hr_agent"), (req, res) => {
  const db = readDB();
  const ticket = db.tickets.find((t) => t.id === Number(req.params.id));
  if (!ticket) return res.status(404).json({ error: "Ticket not found" });

  const { status, priority, assignedTo } = req.body;
  const validStatuses = ["Open", "In Progress", "Resolved", "Closed"];
  if (status) {
    if (!validStatuses.includes(status)) return res.status(400).json({ error: "Invalid status" });
    ticket.status = status;
  }
  if (priority) ticket.priority = priority;
  if (assignedTo !== undefined) ticket.assignedTo = assignedTo;
  ticket.updatedAt = new Date().toISOString();
  writeDB(db);
  res.json({ ticket });
});

router.post("/:id/comments", auth, (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: "Comment text is required" });
  const db = readDB();
  const ticket = db.tickets.find((t) => t.id === Number(req.params.id));
  if (!ticket) return res.status(404).json({ error: "Ticket not found" });
  if (req.user.role !== "hr_agent" && ticket.createdBy !== req.user.id) {
    return res.status(403).json({ error: "You do not have access to this ticket" });
  }
  ticket.comments.push({ author: req.user.name, text, createdAt: new Date().toISOString() });
  ticket.updatedAt = new Date().toISOString();
  writeDB(db);
  res.status(201).json({ ticket });
});

module.exports = router;
