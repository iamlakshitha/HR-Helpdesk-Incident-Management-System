const express = require("express");
const { readDB, writeDB, nextId } = require("../db");
const { auth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.get("/", auth, (req, res) => {
  const db = readDB();
  const { q } = req.query;
  let articles = db.kb;
  if (q) {
    const term = q.toLowerCase();
    articles = articles.filter(
      (a) => a.title.toLowerCase().includes(term) || a.body.toLowerCase().includes(term)
    );
  }
  res.json({ articles });
});

router.get("/:id", auth, (req, res) => {
  const db = readDB();
  const article = db.kb.find((a) => a.id === Number(req.params.id));
  if (!article) return res.status(404).json({ error: "Article not found" });
  res.json({ article });
});

router.post("/", auth, requireRole("hr_agent"), (req, res) => {
  const { title, category, body } = req.body;
  if (!title || !body) return res.status(400).json({ error: "title and body are required" });
  const db = readDB();
  const article = {
    id: nextId(db.kb),
    title,
    category: category || "General HR Query",
    body,
    createdAt: new Date().toISOString(),
  };
  db.kb.push(article);
  writeDB(db);
  res.status(201).json({ article });
});

module.exports = router;
