const express = require("express");
const { readDB } = require("../db");
const { auth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.get("/stats", auth, requireRole("hr_agent"), (req, res) => {
  const db = readDB();
  const tickets = db.tickets;

  const byStatus = {};
  const byCategory = {};
  for (const t of tickets) {
    byStatus[t.status] = (byStatus[t.status] || 0) + 1;
    byCategory[t.category] = (byCategory[t.category] || 0) + 1;
  }

  const now = new Date();
  const openAgingDays = tickets
    .filter((t) => t.status === "Open" || t.status === "In Progress")
    .map((t) => Math.floor((now - new Date(t.createdAt)) / (1000 * 60 * 60 * 24)));

  res.json({
    totalTickets: tickets.length,
    byStatus,
    byCategory,
    avgOpenAgeDays: openAgingDays.length
      ? Math.round((openAgingDays.reduce((a, b) => a + b, 0) / openAgingDays.length) * 10) / 10
      : 0,
    kbArticleCount: db.kb.length,
  });
});

module.exports = router;
