const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { readDB, writeDB, nextId } = require("../db");
const { SECRET, auth } = require("../middleware/auth");

const router = express.Router();

router.post("/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "name, email and password are required" });
  }
  const db = readDB();
  if (db.users.find((u) => u.email === email)) {
    return res.status(409).json({ error: "An account with this email already exists" });
  }
  const user = {
    id: nextId(db.users),
    name,
    email,
    passwordHash: bcrypt.hashSync(password, 8),
    role: "employee", // new signups are always employees; agents are seeded/promoted
  };
  db.users.push(user);
  writeDB(db);
  res.status(201).json({ message: "Account created. You can now log in." });
});

router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find((u) => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  const token = jwt.sign(
    { id: user.id, name: user.name, email: user.email, role: user.role },
    SECRET,
    { expiresIn: "8h" }
  );
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

router.get("/me", auth, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
