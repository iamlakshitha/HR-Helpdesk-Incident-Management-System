// Run with: npm run seed
// Creates data/db.json with demo users, tickets, and knowledge base articles.
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");

const passwordHash = bcrypt.hashSync("password123", 8);

const db = {
  users: [
    { id: 1, name: "Nadeesha Perera", email: "hragent@demo.com", passwordHash, role: "hr_agent" },
    { id: 2, name: "Kasun Silva", email: "employee@demo.com", passwordHash, role: "employee" },
  ],
  tickets: [
    {
      id: 1,
      subject: "Cannot log in to SuccessFactors ESS portal",
      category: "SuccessFactors/ESS Login Issue",
      description: "I get an 'invalid session' error every time I try to log in to the ESS portal.",
      status: "Open",
      priority: "High",
      createdBy: 2,
      assignedTo: 1,
      comments: [
        { author: "Nadeesha Perera", text: "Looking into your SSO session token now.", createdAt: "2026-07-01T09:15:00Z" },
      ],
      createdAt: "2026-07-01T08:30:00Z",
      updatedAt: "2026-07-01T09:15:00Z",
    },
    {
      id: 2,
      subject: "Payslip missing overtime allowance",
      category: "Payroll Query",
      description: "My June payslip does not reflect the overtime hours I logged.",
      status: "In Progress",
      priority: "Medium",
      createdBy: 2,
      assignedTo: 1,
      comments: [],
      createdAt: "2026-07-02T10:00:00Z",
      updatedAt: "2026-07-02T10:00:00Z",
    },
  ],
  kb: [
    {
      id: 1,
      title: "Resetting your SuccessFactors ESS password",
      category: "SuccessFactors/ESS Login Issue",
      body: "1. Go to the ESS login page.\n2. Click 'Forgot Password'.\n3. Enter your employee email.\n4. Check your inbox for a reset link (valid for 30 minutes).\n5. If no email arrives, confirm your employee email is correct in the system and contact HR IT support.",
      createdAt: "2026-06-15T00:00:00Z",
    },
    {
      id: 2,
      title: "Understanding your payslip deductions",
      category: "Payroll Query",
      body: "Your payslip includes basic salary, allowances (transport, meal), and deductions (EPF/ETF, tax, loan repayments if any). If a figure looks incorrect, raise a ticket under 'Payroll Query' with your payslip period and the specific line item in question.",
      createdAt: "2026-06-20T00:00:00Z",
    },
  ],
};

fs.writeFileSync(path.join(__dirname, "data", "db.json"), JSON.stringify(db, null, 2));
console.log("Seeded database at backend/data/db.json");
console.log("Demo logins:");
console.log("  HR Agent:  hragent@demo.com  / password123");
console.log("  Employee:  employee@demo.com / password123");
